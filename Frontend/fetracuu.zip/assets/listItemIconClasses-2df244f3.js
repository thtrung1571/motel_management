import{h as s,e}from"./index-1b925a14.js";function l(t){return e("MuiListItemIcon",t)}const i=s("MuiListItemIcon",["root","alignItemsFlexStart"]),n=i;export{l as g,n as l};
